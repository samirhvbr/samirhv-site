"""Build the visual identity manual. Requires reportlab, svglib and Pillow."""
from pathlib import Path
import colorsys
import json
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics import renderPDF
from svglib.svglib import svg2rlg
from PIL import Image
R=Path(__file__).resolve().parent; A=R/'assets'
identity=json.loads((R/'identity.json').read_text())
Y=identity['palette']['yellowAccent']
yellow_rgb=tuple(int(Y[i:i+2],16) for i in (1,3,5))
yellow_h,yellow_l,yellow_s=colorsys.rgb_to_hls(*(v/255 for v in yellow_rgb))
for w in (400,500,700):pdfmetrics.registerFont(TTFont(f'M{w}',str(R/f'fonts/Manrope-{w}.ttf')))
W,H=960,600; N='#0B1018'; C='#0BB8EE'; F='#F4F7FA'; M='#9BA9BA'; I='#007A9E'
c=canvas.Canvas(str(R/'manual-identidade.pdf'),pagesize=(W,H));c.setTitle('samirhv / Identidade visual / S essencial 02');c.setAuthor('samirhv')
def rect(x,y,w,h,color):c.setFillColor(color);c.rect(x,H-y-h,w,h,fill=1,stroke=0)
def text(s,x,y,size=16,color=N,weight=400):c.setFillColor(color);c.setFont(f'M{weight}',size);c.drawString(x,H-y-size,s)
def lines(ss,x,y,size=16,color=N,step=26):
 for j,s in enumerate(ss):text(s,x,y+j*step,size,color)
def svg(name,x,y,w):
 d=svg2rlg(str(A/name));sc=w/d.width;d.scale(sc,sc);renderPDF.draw(d,c,x,H-y-d.height*sc)
def page(n,title,dark=False):
 bg,fg=(N,F) if dark else (F,N);rect(0,0,W,H,bg);text('samirhv / identidade visual',48,26,11,C if dark else I,500);text(f'S essencial / 02     •     {n:02}',738,26,11,M if dark else I);text(title,48,76,32,fg,700)
 rect(48,556,864,1,'#25303F' if dark else '#D8DEE5');text('Samir Hanna Verza',48,568,10,M if dark else I);text('Proposta de identidade • setembro 2026',660,568,10,M if dark else I)
def end():c.showPage()
page(1,'Engenharia com assinatura.',True)
svg('logo-horizontal-dark.svg',113,217,734)
text('Projetos, ferramentas e código.',119,428,21,M)
text('Um sistema visual preciso, autoral e direto.',119,475,14,F)
end()
page(2,'Um S. Uma assinatura.')
for x in range(60,401,34):rect(x,156,0.5,340,'#D8DEE5')
for y in range(156,497,34):rect(60,y,340,.5,'#D8DEE5')
svg('symbol-cyan.svg',60,156,340)
text('Geometria com intenção',472,165,23,N,700)
lines(['Curvas amplas equilibram os cortes inclinados.', 'A base tem simetria de 180°.', 'Um filete amarelo assina a ponta superior.'],472,219,15)
text('Personalidade',472,340,19,N,700)
lines(['Preciso: estrutura clara e poucos elementos.', 'Autoral: o S funciona como assinatura pessoal.', 'Direto: a comunicação mostra o que foi feito.'],472,382,15)
end()
page(3,'Assinaturas e contraste')
rect(48,151,535,150,N);svg('logo-horizontal-dark.svg',73,182,479)
svg('logo-horizontal-light.svg',73,337,400)
svg('logo-stacked-light.svg',641,173,260)
text('Horizontal / principal',73,315,12,I,500);text('Vertical / espaços compactos',649,390,12,I,500)
rect(48,443,412,84,N);svg('logo-horizontal-white.svg',90,455,285)
svg('logo-horizontal-black.svg',562,455,285)
end()
def luminance(h):
 v=[int(h[i:i+2],16)/255 for i in (1,3,5)];v=[a/12.92 if a<=.04045 else ((a+.055)/1.055)**2.4 for a in v];return sum(a*b for a,b in zip(v,[.2126,.7152,.0722]))
def ratio(a,b):v=sorted([luminance(a),luminance(b)]);return (v[1]+.05)/(v[0]+.05)
page(4,'Cor que identifica. Contraste que funciona.')
for k,(name,h) in enumerate([('Ciano',C),('Grafite',N),('Névoa',F),('Ciano texto',I)]):
 x=48+k*222;rect(x,160,204,180,h);text(name,x,358,19,N,700);text(h,x,388,14,I,500)
rect(48,425,18,4,Y);text(f'Amarelo puro {Y}: cor de acento. Especificação completa na página 05.',80,415,13,N)
lines([f'Ciano / grafite: {ratio(C,N):.1f}:1     •     Névoa / grafite: {ratio(F,N):.1f}:1',f'Ciano texto / névoa: {ratio(I,F):.1f}:1     •     combinações para texto corrente'],48,450,16)
text('Sobre fundo claro, reserve o ciano vivo ao símbolo e a detalhes gráficos.',48,512,13,I)
end()
page(5,'Amarelo puro / especificação')
# This enlarged swatch documents the color; it is not an application example.
rect(48,154,312,84,Y);text('AMARELO PURO',68,170,12,N,700);text(Y,68,190,25,N,700)
rect(48,259,312,230,N);svg('symbol-cyan.svg',99,274,200)
text('Aplicação: só na ponta superior do S.',48,505,13,I)
text('Referência digital / sRGB',408,151,20,N,700)
specs=[('HEX',Y),('RGB',' / '.join(map(str,yellow_rgb))),('HSL',f'{yellow_h*360:.0f}° / {yellow_s*100:.0f}% / {yellow_l*100:.0f}%'),('Opacidade','100% - cor chapada')]
for j,(label,value) in enumerate(specs):
 y=195+j*30;text(label,408,y,13,I,500);text(value,535,y,15,N,500)
text('Proporção do detalhe',408,332,18,N,700)
lines([f"Filete: {identity['accent']['widthIn100UnitGrid']} unidades na horizontal, em uma grade de 100.", 'Equivale a 2,5% da largura visível do S (80 unidades).', 'Altura: 15 unidades. Inclinação igual à ponta original.'],408,366,13,step=22)
lines(['Favicon: filete óptico de 0,75 unidade na grade de 16.', 'Uso único, contido na silhueta. Sem repetição no nome,', 'no terminal inferior ou nos fundos. Omitir em monocromia.'],408,447,13,step=22)
end()
page(6,'Tipografia com presença')
text('Manrope',48,148,76,N,700);text('Aa 0123456789',50,255,35,I,500)
lines(['Uma família para títulos, interface e texto.', 'O nome da marca usa peso 750 e espaçamento próprio.', 'Nos arquivos finais, as letras já estão em curvas.'],50,341,16)
text('Hierarquia sugerida',565,162,21,N,700)
text('Engenharia útil.',565,222,35,N,700)
text('Projetos com propósito',566,281,21,N,500)
lines(['Descreva o problema, a solução e', 'como começar. Prefira evidência', 'a promessas genéricas.'],566,331,16)
text('700 títulos  /  500 rótulos  /  400 texto',566,450,13,I)
text('Monoespaçada apenas em código e dados técnicos.',50,514,13,I)
end()
page(7,'Pequeno também é marca.',True)
svg('app-icon-cyan.svg',48,164,192);svg('app-icon-dark.svg',275,164,192)
text('Ícone / avatar',48,386,16,F,500)
text('Favicon com ajuste óptico',551,164,20,F,700)
for x,n in [(558,16),(650,32),(760,48)]:
 c.drawImage(str(A/f'favicon-{n}.png'),x,H-273-n,width=n,height=n,mask='auto');text(f'{n} px',x,342,13,M)
lines(['Aberturas ampliadas e menos detalhes.', 'O favicon usa uma placa para preservar', 'a leitura em abas claras e escuras.'],551,402,15,M)
text('Fonte mobile: quadrada, opaca e sem cantos pré-recortados.',48,512,13,M)
end()
page(8,'Espaço para respirar')
# Clearspace = 20 units, quarter of visible 80-unit symbol height.
rect(48,164,535,176,'#E5EBF0');svg('logo-horizontal-light.svg',72,185,487)
c.setStrokeColor(I);c.setLineWidth(.7);c.setDash(3,3);c.rect(60,H-328,511,152,stroke=1,fill=0);c.setDash()
text('x = ¼ da altura visível do S',48,372,18,N,700)
lines(['Mantenha pelo menos x de respiro em todos os lados.', 'Meça a partir do desenho, não da borda do arquivo.', 'Não estique, incline, contorne ou acrescente brilho.'],48,415,15)
text('Mínimos digitais',649,171,21,N,700)
svg('logo-horizontal-light.svg',649,234,160);text('Assinatura: 160 px de largura',649,296,13,I)
svg('symbol-navy.svg',649,356,30);text('Símbolo: 24 px visíveis',649,405,13,I)
text('Abaixo disso, use o favicon.',649,450,13,I)
end()
page(9,'Aplicações da identidade',True)
c.drawImage(str(A/'social-cover.png'),48,H-151-287.175,width=547,height=287.175)
svg('app-icon-cyan.svg',676,169,144)
text('Assinatura pessoal',651,352,18,F,700)
lines(['Samir Hanna Verza', 'samirhv.com.br'],651,392,15,M)
text('Capa social • arquivo pronto em 1200 × 630 px',48,465,13,M)
text('Elementos planos, alinhamentos simples e uma diagonal como apoio.',48,513,13,M)
end()
page(10,'Pronta para ganhar aplicações')
text('O que acompanha a marca',48,158,24,N,700)
lines(['01  Logos horizontais e verticais em SVG e PNG.', '02  Símbolo, versões monocromáticas e wordmark.', '03  Favicons, ícones, capa social e capa de repositório.', '04  Tipografia licenciada, cores e tokens de referência.', '05  Fontes vetoriais e scripts para novas exportações.'],48,219,17,step=43)
rect(625,157,287,354,N);text('Status desta edição',649,185,19,F,700)
lines(['Identidade proposta para', 'a marca pessoal samirhv.', '', 'O estudo anterior continua', 'preservado em s-essencial.', '', 'A aplicação no site fica', 'para uma etapa própria.'],649,239,14,M,25)
text('Consulte README.md para formatos, licenças e instruções de uso.',48,516,13,I)
end();c.save()
ims=[Image.open(A/f'favicon-{n}.png') for n in (16,32,48)]
ims[-1].save(A/'favicon.ico',format='ICO',sizes=[(16,16),(32,32),(48,48)],append_images=ims[:-1])
print('Manual and ICO generated')
